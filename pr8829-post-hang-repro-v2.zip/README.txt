86Box PR #8829 POST hang repro, v2 (ASUS PVI-486SP3, iDX4-100, recompiler on)

Contents: 86box.cfg, nvr/ (CMOS + S3 EEPROM after one normal boot), disk.vhd (empty
8.9 GB SCSI disk: partition table + a 20-instruction test MBR (testmbr.asm) that
prints one line and halts; no partition contents).
v1 of this zip had a disk without MBR boot code, which hangs on master too after
"Update ESCD Successfully" (the BIOS jumps into the zeros at 0000:7C00).

Run:  86Box -P <this folder>   (use a fresh copy of the folder per try: the BIOS rewrites nvr/)

master: the BIOS "System Configurations" box, "Update ESCD Successfully",
"Boot successful (test MBR, no operating system on this disk)."
#8829 (dbdeff59a): about half of the boots stop right after the box, before
"Update ESCD Successfully".
