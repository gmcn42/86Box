; Test MBR: prints a line through the BIOS and halts. Boot code only; the partition
; table and the 55 AA signature are taken from the disk image.
        org     0x7c00
        bits    16
start:  cli
        xor     ax, ax
        mov     ds, ax
        mov     ss, ax
        mov     sp, 0x7c00
        sti
        mov     si, msg
.next:  lodsb
        test    al, al
        jz      .halt
        mov     ah, 0x0e
        mov     bx, 0x0007
        int     0x10
        jmp     .next
.halt:  hlt
        jmp     .halt
msg:    db      "Boot successful (test MBR, no operating system on this disk).", 13, 10, 0
        times   446 - ($ - $$) db 0
