86Box PR #8829 POST hang repro (ASUS PVI-486SP3, iDX4-100, recompiler on)

Contents: 86box.cfg, nvr/ (CMOS + S3 EEPROM after one normal boot), disk.vhd (empty
8.9 GB SCSI disk, only a partition table: no boot code, no files).

Run:  86Box -P <this folder>

Expected (master): the BIOS "System Configurations" box, then "Update ESCD Successfully"
and "DISK BOOT FAILURE, INSERT SYSTEM DISK AND PRESS ENTER" (the disk has no OS).
With #8829 (8e951f43d): about half of the boots stop right after the box, before
"Update ESCD Successfully". Each test boot started from a fresh copy of this folder
(the BIOS rewrites nvr/).
With a fresh NVR the BIOS stops at "Press F1 to continue" first; after F1 it hangs less
often (about 1 in 3 here).
